let l = [(0, "first"); (1, "second"); (2, "third")];

print_endline(List.assoc 0 l);
